use Intellij(Intellij IDEA 2019.2)

JDK version 1.8

Use  stdlib jar file to use the stopwatch class
steps for adding jar file to intellij
path--->(file > project structure > libraries > add the java library )